<?php

class WPSC_Query_Controller extends WPSC_Controller {
	/* public function _filter_comments_array() {}
	public function _action_reset_globals() {}
	public function _action_replace_content() {} */
}