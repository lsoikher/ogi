<?php
_wpsc_deprecated_file(
	__FILE__,
	'3.9',
	'',
	__( 'The sole function that existed in users.php has now been deprecated.', 'wp-e-commerce' )
);