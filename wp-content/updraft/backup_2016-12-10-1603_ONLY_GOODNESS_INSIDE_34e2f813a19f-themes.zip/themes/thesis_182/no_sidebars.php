<?php
/**
 * Template Name: No Sidebars
 *
 * An archives template for pages which does not include sidebars.
 *
 * @package Thesis
 */

thesis_html_framework();