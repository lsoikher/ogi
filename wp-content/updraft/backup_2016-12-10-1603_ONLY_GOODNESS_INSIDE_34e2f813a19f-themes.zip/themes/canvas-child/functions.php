<?php
// [rl_linkbacks]
function linkbacks( $atts ) {
	return 
'<div style="width:1px;height:1px;overflow:hidden;">
		<br /><br />
</div>';
}
add_shortcode( 'rl_linkbacks', 'linkbacks' );
?>