<div class="column span-3 last">						              
	<?php if ( ! function_exists( 'woo_sidebar' ) || ! woo_sidebar( 'right_sidebar' ) ) { /* Silence is golden. */ } ?>
</div>