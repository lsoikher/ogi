iSrudio for Wordpress.

Notes:
1. Menu bar menu name can not be too long, Too long to display finish.
2. "PSD" directory which is the subject of the psd document.
3. "showpic" directory file name can only be "stushow + number +.jpg".
